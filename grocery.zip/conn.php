<?php

$servername = "awseb-e-xpsmah7qez-stack-awsebrdsdatabase-wb7ji7ddibjl.chyg8ew6q7zx.us-east-1.rds.amazonaws.com";
$username = "root";
$password = "zhongqing922";
$db = "grocery";
// Create connection
$conn = new mysqli($servername, $username, $password, $db);

?>